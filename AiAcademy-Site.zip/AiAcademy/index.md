---
layout: default
title: Home
---

# Welcome to AiAcademy

Learn the basics of Artificial Intelligence in a simple and clear way.

[Start Learning](./pages/what-is-ai.html)