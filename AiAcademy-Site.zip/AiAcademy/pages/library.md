---
layout: default
title: Library
---

## Additional Resources

- [AI for Beginners (Microsoft)](https://github.com/microsoft/AI-For-Beginners)
- [Google AI Education](https://ai.google/education/)
- [Coursera - AI Basics](https://www.coursera.org/)