---
layout: default
title: FAQ
---

## Frequently Asked Questions

**Q: Is AI only about robots?**  
A: No, AI includes systems like voice assistants, recommendation engines, and more.

**Q: Can I learn AI without coding?**  
A: Yes, especially the concepts and applications.