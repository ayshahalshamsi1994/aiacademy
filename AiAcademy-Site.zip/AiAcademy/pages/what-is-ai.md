---
layout: default
title: What is AI?
---

## What is Artificial Intelligence?

Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think and learn.

AI is used in many fields such as healthcare, education, finance, and more.