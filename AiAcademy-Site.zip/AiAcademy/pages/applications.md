---
layout: default
title: Applications
---

## Applications of AI

- Healthcare
- Supply Chain
- Education
- Finance
- Smart Cities